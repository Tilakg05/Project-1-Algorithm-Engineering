# Project-1
Implementing algorithms

Group members:

Trinh Hoang trinhhoang2020@csu.fullerton.edu

Tilak Ghorashainee Tilakg05@csu.fullerton.edu
